alert ("Thank you for installing SlatePanel! Please refer to the README file in c:/user/appdata/slatepanel/ to see how to set up SlatePanel. You must do this in order for SlatePanel to work!")
