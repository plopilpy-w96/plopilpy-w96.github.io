// Ran upon package installation
w96.sys.execCmd(`internete`, 'c:/local/slateweather/install.html')