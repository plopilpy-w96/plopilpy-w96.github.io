SlateWeather Copyright (c) 2022 Plopilpy.

Please do not redistribute or modify code.